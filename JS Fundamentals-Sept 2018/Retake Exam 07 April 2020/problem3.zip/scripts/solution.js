
function solve() {
    const availableInput = Array.from(document.querySelectorAll("#availableCourses > div.courseBody > ul > li input[type=checkbox]"));
    const signMeBtn = document.querySelector("#availableCourses > div.courseFoot > button");
    const educFormsInput = Array.from(document.querySelectorAll("#educationForm > input"));
    const costP = document.querySelector("#myCourses > div.courseFoot > p");
    const myCoursesUl = document.querySelector("#myCourses > div.courseBody > ul");
    let totalSum = 0;
    const priceMap = {
        'js-fundamentals': 170,
        'js-advanced': 180,
        'js-applications': 190,
        'js-web': 490
    };
    let selectedCourses = new Set();

    signMeBtn.addEventListener('click', function () {

        for (let i = 0; i < availableInput.length; i++) {
            let current=availableInput[i];
            if (current.checked) {
                let textData=current.parentNode.lastElementChild.textContent;
                let text=textData.split(' - ')[0].split(' ')
                    .join('-');
                let li = document.createElement('li');
                li.innerHTML=text;
                selectedCourses.add(current.value);
                totalSum+=priceMap[current.value];
                myCoursesUl.appendChild(li);
            }
        }

        if (selectedCourses.has('js-fundamentals')&&selectedCourses.has('js-advanced')&&selectedCourses.has('js-applications')){
            totalSum=Math.round(totalSum-32.40);
        }
        if (selectedCourses.has('js-fundamentals')&&selectedCourses.has('js-advanced')){
            totalSum-=18;
        }
        if (educFormsInput[1].checked){
            totalSum=Math.round(totalSum*0.94);
        }
        if (selectedCourses.size===4){
            let li = document.createElement('li');
            li.innerHTML='HTML and CSS';
            myCoursesUl.appendChild(li);

        }
        costP.textContent=`Cost: ${(Math.floor(totalSum)).toFixed(2)} BGN`;
    })
}

solve();